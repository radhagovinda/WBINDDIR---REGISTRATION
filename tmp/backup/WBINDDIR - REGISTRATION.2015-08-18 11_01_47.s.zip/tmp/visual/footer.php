</div>
				<!--End Main Content Area here-->
				
				<!--Edit Sidebar Content here--><!--End Sidebar Content here-->
            </div>

            <div id="footerInnerSeparator"></div>
        </div>
    </div>

    <div id="footerOuterSeparator"></div>

    <div id="divFooter" class="footerArea">

        <div class="divPanel">

            <div class="row-fluid">
                <div class="span3" id="footerArea1">
                
                    <h3>About Company</h3>

                    <p>wbindustrialdirectory.com is a volunteer project of <strong>Brainscape</strong>. The same Brainscape, who are the pioneers of web developemnt industry in Eastern India.</p>
                    
                    <p> 
                        <a href="#" title="Terms of Use">Terms of Use</a><br />
                        <a href="#" title="Privacy Policy">Privacy Policy</a><br />
                        <a href="#" title="FAQ">FAQ</a><br />
                        <a href="#" title="Sitemap">Sitemap</a>
                    </p>

                </div>
                <div class="span3" id="footerArea2">

                    <h3>Recent Blog Posts</h3> 
                    <p>
                        <a href="#" title="">failed to connect with blog server</a><br />
                        <span style="text-transform:none;"># hours ago</span>
                    </p>
                    <p><a href="#" title="">failed to connect with blog server</a><br />
                        <span style="text-transform:none;"># hours ago</span>
                    </p>
                    <p>
                        <a href="#" title="">failed to connect with blog server</a><br />
                        <span style="text-transform:none;"># hours ago</span>
                    </p>
                    <p>
                        <a href="#" title="">VIEW ALL POSTS</a>
                    </p>

                </div>
                <div class="span3" id="footerArea3">

                    <h3>&nbsp;</h3>

                </div>
                <div class="span3" id="footerArea4">

                    <h3>Get in Touch</h3>  
                                                               
                    <ul id="contact-info">
                    <li>                                    
                        <i class="general foundicon-phone icon"></i>
                        <span class="field">Phone:</span>
                        <br />
                        (+91) 980 425 0045 / 908 851 8998                                                                      
                    </li>
                    <li>
                        <i class="general foundicon-mail icon"></i>
                        <span class="field">Email:</span>
                        <br />
                        <a href="mailto:info@yourdomain.com" title="Email">wb.id@outlook.com</a>
                    </li>
                    <li>
                        <i class="general foundicon-home icon" style="margin-bottom:50px"></i>
                        <span class="field">Address:</span>
                        <br />
                        10/57 N. Nagar<br />
                        2nd Floor, Suit # J Kolkata, West Bengal<br />
                        INDIA
                    </li>
                    </ul>

                </div>
            </div>

            <br /><br />
            <div class="row-fluid">
                <div class="span12">
                    <p class="copyright">
                        Copyright � 2013 Your Company. All Rights Reserved.
                    </p>

                    <p class="social_bookmarks">
                        <a href="#"><i class="social foundicon-facebook"></i>�Facebook</a>
			<a href=""><i class="social foundicon-twitter"></i>�Twitter</a>
			<a href="#"><i class="social foundicon-pinterest"></i>�Pinterest</a>
			<a href="#"><i class="social foundicon-rss"></i>�Rss</a>
                    </p>
                </div>
            </div>

        </div>
    </div>
</div>
<br /><br /><br />

<script src="../scripts/jquery.min.js" type="text/javascript"></script> 
<script src="../scripts/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
<script src="../scripts/default.js" type="text/javascript"></script>





</body>
</html>